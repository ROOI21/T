#pragma once

#define HTTP_SERVER "159.65.165.194"
#define HTTP_PORT 80

#define TFTP_SERVER "159.65.165.194"
